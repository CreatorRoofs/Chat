import { useEffect, useState } from "react"

export const useLocalStorage = (key, defaultValue) => {
    const [state, setState] = useState(() => {
        let value
        if (window.localStorage.getItem(key)) {
            value = JSON.parse(window.localStorage.getItem(key))
        } else {
            value = defaultValue
        }
        return value
    })
    useEffect( () => {
        window.localStorage.setItem(key, JSON.stringify(state))
    }, [state] )
    return [state, setState]
}