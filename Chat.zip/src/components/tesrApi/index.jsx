import styles from "./style.module.css";
const TestApi = () => {
    return(
        <div>
            <h1>Привет</h1>
        </div>
    )
}
export default TestApi