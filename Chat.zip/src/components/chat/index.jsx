import { useState } from "react";
import styles from "./style.module.css";
import ChatBlock from "./chat-block";
import Comment from "./comment";
import { useLocalStorage } from "../../hook/useLocalStorage";
const Chat = () => {
    const [chatData, setChatData] = useLocalStorage("CHAT", ["Привет всем!"])
    
    const ChangeChat = () => {
        if (user) {
            setChatData([...chatData, `${user}: ${inputValue}`]);
            setInputValue("")
        } else {
            setShowDialogReg(true);
            setInputValue("")
            // <div>
            //     Зарегистрируйтесь, чтобы вы смогли писать сообщения
            // </div>
        }
    }
    const [inputValue, setInputValue] = useState("")
    const [showDialogReg, setShowDialogReg] = useState(false)

    const [user] = useLocalStorage("USER")

    // const DeleteMass = (el, i) => {
    //     if (user){
    //         setChatData([chatData.shift(el, i)])
    //     }
    // }
 

    return(
        <div>
            {/* {chatData.map((el) => {
                return <div>{el}</div>
            })} */}
            <ChatBlock 
            chatData={chatData}
            />
            <Comment 
            inputValue={inputValue}
            setInputValue={setInputValue}
            ChangeChat = {ChangeChat}
            setChatData = {setChatData}
            showDialogReg = {showDialogReg}
            // DeleteMass = {DeleteMass}
            />
            {/* <button onClick={ChangeChat}>Добавить</button> */}

        </div>
    )
}
export default Chat