import {Route, Switch} from "react-router"
import styles from "./style.module.css";
import Home from "../home";
import Chat from "../chat";
import TestApi from "../tesrApi";
import BrainHouse from "../BrainHause";
const Main = () => {
    return(
        <div className={styles.container}>
        <Switch>
            <Route exact path="/" component={Home}/>
            <Route path="/chat" component={Chat}/>
            <Route path="/test" component={TestApi}/>
            <Route path="/smart" component={BrainHouse}/>
        </Switch>
        </div>
    )
}

export default Main