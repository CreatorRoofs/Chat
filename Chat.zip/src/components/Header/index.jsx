import {Link} from "react-router-dom" 
import styles from "./style.module.css";
const Header = () => {
    return(
        <div className={styles.conteiner}>
            <nav className={styles.navbar}>
                {/* <div>Главная страница</div>
                <div>Чат</div>
                <div>Подгрузка данных</div> */}
                <Link className={styles.link} to="/">Главная страница</Link>
                <Link className={styles.link} to="/chat">Чат</Link>
                <Link className={styles.link} to="/test">Подгрузка данных</Link>
                <Link className={styles.link} to="/smart">Умный дом</Link>
            </nav>
        </div>
    )
}
export default Header