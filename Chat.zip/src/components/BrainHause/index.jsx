import styles from "./style.module.css"
import { useState } from "react"
import {useLocalStorage} from "../../hook/useLocalStorage"
const BrainHouse = () => {
    const [devise, setDevise] = useLocalStorage("SMART",
    [ 
        {id: 1, name: "Лампочка", isPower: false, isEdit: false}, 
        {id: 2, name: "Телевизор", isPower: false, isEdit: false}, 
        {id: 3, name: "Колонка", isPower: false, isEdit: false}, 
    ])

    //Добавить

    const handleAdd = () => {
        setDevise([
            ...devise, 
        {
            id: devise.length === 0 ? 1 : devise[devise.length - 1].id + 1, 
            name: addValue,
            isPower: false,
            isEdit: false,
        }])
        setAddValue("")
    };

    //Удалить
    const handleDelete = (idDevise) => {
        setDevise(() => devise.filter(el => el.id !== idDevise));
    }
    const [addValue, setAddValue] = useState("")
    
    //вкл/вкл
    const handlePower = (idDevice) => {
        setDevise(() => devise.map(el => {
            if(el.id === idDevice) {
                return{...el, isPower: !el.isPower};
            }
            return el
        }))
    }
    
    //Редактирование
    const [editValue, setEditValue] = useState("")
    const showEditDialog = (idDevice) => {
        setDevise(() => devise.map(el => {
            if(el.id === idDevice){
                setEditValue(el.name)
                return {...el, isEdit: true}
            }
            return {...el, isEdit: false};
        }))
    };

    const handleEdit = (idDevice) => {
        setDevise(() => 
            devise.map((el) => {
                if(el.id === idDevice){
                    return {...el, name: editValue, isEdit: false}
                }
                return el;
            })
        )
    }
    

    return (
        <div className={styles.main_container}>
            <input value={addValue} onChange={(e) => setAddValue(e.target.value)}/>
            <button onClick={handleAdd}>Клик</button>
            <div className={styles.container_item}>
                {devise.map((el) => {
                    return (
                    <div>
                        {el.isEdit ? (
                            <div className={styles.edit}>
                                <input
                                value={editValue}
                                onChange={(e) => setEditValue(e.target.value)}
                                />
                                <button onClick={() => handleEdit(el.id)}>Сохранить</button>
                            </div>
                        ) : (
                            <div className={styles.item}>
                                <div> {el.name} </div>
                                <div>
                                <button style={
                                el.isPower ? {background: "red"} : {background: "#00ff00"}} 
                                onClick={() => handlePower(el.id)}>
                                {el.isPower ? "Отключить" : "Включить"}
                                </button>
                                <button onClick={() => showEditDialog(el.id)}>Ред.</button>
                                <button onClick={() => handleDelete(el.id)}>Очистить</button>
                                </div>
                            </div>
                        )}
                    </div>);
                })}
            </div>
        </div>
    )
}

export default BrainHouse