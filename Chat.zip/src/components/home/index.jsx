import { useState } from "react";
import styles from "./style.module.css";
import { useLocalStorage } from "../../hook/useLocalStorage";
const Home = () => {
    const [user, setUser] = useLocalStorage("USER", "") // Изменяем UseState("") на useLocalStorage() для того, чтобы полученные с user данные сохранялись на сайте
    const [inputValue, setInputValue] = useState("")
    return(
        <div>
            {user && (
                <div>
                    <div>Здравствуйте, уважаемый {user}</div>
                    <button onClick={() => setUser("")}>Выйти</button>
                </div>
            )}
        
            {!user && (
                <div>
                    <label>Введите ваше имя</label>
                    <input 
                    value={inputValue} 
                    onChange={(e) => setInputValue(e.target.value)}/>
                    <button onClick={() => setUser(inputValue)}>Сохранить</button>
                </div>
            )}
        </div>
    )
}
export default Home